import{a as e}from"./index-D1cmtgFh.js";const a={getStats:async()=>(await e.get("/public/stats")).data,getLandingNews:async()=>(await e.get("/news/landing")).data};export{a as default};
